const PdfLib = require('pdf-lib');
const fontkit = require('@pdf-lib/fontkit')
const fs = require('fs');
const AWS = require('aws-sdk');
const moment = require('moment');


AWS.config.update({ region: 'eu-west-3' });

const now = moment();

async function getObjectFromS3() {
  const s3 = new AWS.S3({
    accessKeyId: process.env.BB_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.BB_AWS_SECRET_ACCESS_KEY,
  });
  const params = {
    Bucket: "clevy.io-covidbotpublic",
    Key: "ressources/attestation_de_deplacement_derogatoire.pdf"
  };
  return s3.getObject(params).promise().then((data) => {
    console.log(data)
    return data
  });
}

async function uploadFileToS3(pdfBytes) {
  const buffer = new Buffer.from(pdfBytes)
  const s3 = new AWS.S3({
    accessKeyId: process.env.BB_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.BB_AWS_SECRET_ACCESS_KEY,
  });
  const newFileName = `${Math.random() * (9999999999999 - 1000000000000) + 1000000000000}-attestation_de_deplacement_derogatoire.pdf`
  const params = {
    Bucket: 'clevy.io-covidbotpublic',
    Key: `ressources/${newFileName}`,
    Body: buffer,
    ContentType: 'application/pdf',
    ACL: 'public-read',
  };
  return s3.upload(params).promise().then(
    function (data) {
      console.log(data.Location)
      return data.Location
    }).catch(
      function (err) {
        console.error(err, err.stack);
      });
}

async function sendEmail(url) {
  const senderEmail = 'noreply@covidbot.fr';
  const toEmail = ['antoinederoja@gmail.com'];
  const params = {
    Destination: {
      ToAddresses: toEmail
    },
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: `Please find below a new incoming work order from Bastien, bastien@clevy.io <br><a href="${url}">${url}</a>`
        },
        Text: {
          Charset: "UTF-8",
          Data: `Please find below a new incoming work order from Bastien, bastien@clevy.io - ${url}`
        }
      },
      Subject: {
        Charset: "UTF-8",
        Data: "New work order from Bastien"
      }
    },
    Source: senderEmail,
  };
  const sendPromise = new AWS.SES({
    apiVersion: '2010-12-01',
    accessKeyId: process.env.BB_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.BB_AWS_SECRET_ACCESS_KEY,
  })
    .sendEmail(params).promise();

  return sendPromise.then(
    function (data) {
      console.log(data.MessageId);
    }).catch(
      function (err) {
        console.error(err, err.stack);
      });
}

async function createFile(pdfBytes) {
  fs.writeFile("/Users/bastienbotella/web_docs/eun-digital/clevy/csml/functions/covid_pdf/attestation_deplacement.pdf", pdfBytes, (err) => {
    console.log("The file was saved!");
  });
}

async function updatePdf(params) {
  const pdfModel = await getObjectFromS3();
  const pdfDoc = await PdfLib.PDFDocument.load(pdfModel.Body)

  // Custom font setting
  const fontBytes = fs.readFileSync('fonts/September-Mornings.ttf')
  // Register the `fontkit` instance
  pdfDoc.registerFontkit(fontkit)
  // Embed our custom font in the document
  const DancingScriptFont = await pdfDoc.embedFont(fontBytes)
  const HelveticaFont = await pdfDoc.embedFont(PdfLib.StandardFonts.Helvetica)

  const pages = pdfDoc.getPages()
  const page = pages[0]

  const { width, height } = page.getSize()
  const fontSize = 14

  page.drawText(params.name, {
    x: 138,
    y: height - 222,
    size: fontSize,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.birthdate, {
    x: 138,
    y: height - 250,
    size: fontSize,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.address.slice(0, 50), {
    x: 138,
    y: height - 285,
    size: fontSize,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.address.slice(50, 100), {
    x: 138,
    y: height - 300,
    size: fontSize,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.address.slice(100, 150), {
    x: 138,
    y: height - 315,
    size: fontSize,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.location, {
    x: 370,
    y: 140,
    size: fontSize - 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(now.format('D'), {
    x: 477,
    y: 140,
    size: fontSize - 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(now.format('MM'), {
    x: 503,
    y: 140,
    size: fontSize - 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  page.drawText(params.name, {
    x: params.sigX || 310,
    y: params.sigY || 80,
    size: fontSize + params.sigSize || 100,
    font: DancingScriptFont,
    color: PdfLib.rgb(0, 0, 0),
  })

  // 1:job|2:food|3:health|4:help|5:quick
  // 1st
  page.drawText(params.reason == 'job' ? 'X' : '', {
    x: 50,
    y: 423,
    size: fontSize + 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  // 2nd
  page.drawText(params.reason == 'food' ? 'X' : '', {
    x: 50,
    y: 349,
    size: fontSize + 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  // 3rd
  page.drawText(params.reason == 'health' ? 'X' : '', {
    x: 50,
    y: 303,
    size: fontSize + 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  // 4th
  page.drawText(params.reason == 'help' ? 'X' : '', {
    x: 50,
    y: 272,
    size: fontSize + 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })
  // 5th
  page.drawText(params.reason == 'quick' ? 'X' : '', {
    x: 50,
    y: 227,
    size: fontSize + 3,
    font: HelveticaFont,
    color: PdfLib.rgb(0, 0, 0),
  })

  const pdfBytes = await pdfDoc.save();
  // createFile(pdfBytes)
  const fileUrl = await uploadFileToS3(pdfBytes);
  // return sendEmail(fileUrl);
  return fileUrl
}

exports.handler = async function handler(event) {
  return updatePdf(event)
}

// (async function () {
//   const params = {
//     name: "Bastien Bot",
//     birthdate: "8 Juillet 1986",
//     address: "13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum13 rue du faubourg du lorem ipsum",
//     location: "Paris",
//     // 1:job|2:food|3:health|4:help|5:quick
//     reason: "quick",
//   }
//   await updatePdf(params);
// })();
