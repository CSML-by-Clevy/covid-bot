const util = require('util');
const moment = require('moment');
const csv = require('csvtojson');
const GithubContent = require('github-content');

const addUp = (places) => {
  const total = {
    confirmed: 0,
    deaths: 0,
    recovered: 0,
  }
  for (let i = 0; i < places.length; i++) {
    total.confirmed += parseInt(places[i].Confirmed);
    total.deaths += parseInt(places[i].Deaths);
    total.recovered += parseInt(places[i].Recovered);
  }
  return total
}

const getDatas = async () => {
  const fetchDatasFromGithub = async (date) => {
    const options = {
      owner: 'CSSEGISandData',
      repo: 'COVID-19',
      branch: 'master'
    };
    const gc = new GithubContent(options);
    gc.asyncfile = util.promisify(gc.file);
    const stats = await gc.asyncfile(`csse_covid_19_data/csse_covid_19_daily_reports/${date}.csv`);
    return stats.contents.toString();
  };
  for (let i = 0; i < 5; i++) {
    const strStats = await fetchDatasFromGithub(moment().subtract(i + 1, 'days').format('MM-DD-YYYY'))
    if (strStats.indexOf("404: Not Found") === -1)
      return strStats
  }
};

const getStats = async (datas, country) => {
  return csv({
    noheader: false,
    output: "json"
  })
  .fromString(datas)
  .then((csvRow) => {
    if (country && country.toLowerCase() !== 'global') {
      const filtered_res = csvRow.filter(r => r["Country/Region"] == country);
      return Object.assign(addUp(filtered_res), { place: country })
    }
    else return Object.assign(addUp(csvRow), { place: 'global' })
  });
};

exports.handler = async function handler(event) {
  const datas = await getDatas();
  const stats = await getStats(datas, event.country);
  return stats
};


// (async () => {
//   try {
//     const datas = await getDatas();
//     const stats = await getStats(datas, "global");
//     console.log("final log", stats);
//     return stats
//   } catch (err) {
//     console.log("errrrrrror !", err);
//   }
// })();
